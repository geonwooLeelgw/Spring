package com.with.project.vo;

public class RoomVO {
	private int roomId;
	private String rStart;
	private String rEnd;
	private String preTime;
	private String preDistance;
	private String preMoney;
	private String opGender;
	private String rId1;
	private String rId2;
	private String rId3;
	private String rId4;
	private String dayDay;
	private String times;
	private String maximum;
	private String driverId;
	private String finalMoney;
	
	public String getFinalMoney() {
		return finalMoney;
	}
	public void setFinalMoney(String finalMoney) {
		this.finalMoney = finalMoney;
	}
	public String getDriverId() {
		return driverId;
	}
	public void setDriverId(String driverId) {
		this.driverId = driverId;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public String getrStart() {
		return rStart;
	}
	public void setrStart(String rStart) {
		this.rStart = rStart;
	}
	public String getrEnd() {
		return rEnd;
	}
	public void setrEnd(String rEnd) {
		this.rEnd = rEnd;
	}
	public String getPreTime() {
		return preTime;
	}
	public void setPreTime(String preTime) {
		this.preTime = preTime;
	}
	public String getPreDistance() {
		return preDistance;
	}
	public void setPreDistance(String preDistance) {
		this.preDistance = preDistance;
	}
	public String getPreMoney() {
		return preMoney;
	}
	public void setPreMoney(String preMoney) {
		this.preMoney = preMoney;
	}
	public String getOpGender() {
		return opGender;
	}
	public void setOpGender(String opGender) {
		this.opGender = opGender;
	}
	public String getrId1() {
		return rId1;
	}
	public void setrId1(String rId1) {
		this.rId1 = rId1;
	}
	public String getrId2() {
		return rId2;
	}
	public void setrId2(String rId2) {
		this.rId2 = rId2;
	}
	public String getrId3() {
		return rId3;
	}
	public void setrId3(String rId3) {
		this.rId3 = rId3;
	}
	public String getrId4() {
		return rId4;
	}
	public void setrId4(String rId4) {
		this.rId4 = rId4;
	}
	public String getDayDay() {
		return dayDay;
	}
	public void setDayDay(String dayDay) {
		this.dayDay = dayDay;
	}
	public String getTimes() {
		return times;
	}
	public void setTimes(String times) {
		this.times = times;
	}
	public String getMaximum() {
		return maximum;
	}
	public void setMaximum(String maximum) {
		this.maximum = maximum;
	}
	
	
	
	}
