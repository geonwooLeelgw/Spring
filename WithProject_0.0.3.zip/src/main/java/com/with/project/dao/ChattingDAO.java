package com.with.project.dao;

public class ChattingDAO {

}
